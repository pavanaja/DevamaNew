﻿Installing fonts: 

Fedora or other linux distro: 

  1. Using graphics user interface

          Open otf using gnome-font-viewer or kfontview

          Click on install fonts

  2.  Using terminal:
           copy font to /~.local/share/fonts
           run $fc-cache
           open gedit, it should be listed now


Windows: 
	1. Documented on http://windows.microsoft.com/en-in/windows-vista/install-or-uninstall-fonts
	2. https://support.microsoft.com/en-us/kb/314960
	3. https://www.microsoft.com/en-us/Typography/TrueTypeInstall.aspx
	4. http://www.cnet.com/how-to/how-to-add-remove-and-modify-fonts-in-windows-10/


Mac:
	1. Guide at http://support.apple.com/kb/PH5955